program that plays a choose your own adventure game
