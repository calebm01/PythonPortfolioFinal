Program that initiates a trivia game that the user is scored on
