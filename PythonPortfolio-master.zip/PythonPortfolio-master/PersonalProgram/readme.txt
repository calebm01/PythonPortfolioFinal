This program is a refined rpg inspired by previous rpgs I've made that were much simpler, this rpg game is more complex and has multiple improvements
